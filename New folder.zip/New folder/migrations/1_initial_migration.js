var blog = artifacts.require ("./Blog.sol");

module.exports = function(deployer) {
  deployer.deploy(blog);
};
