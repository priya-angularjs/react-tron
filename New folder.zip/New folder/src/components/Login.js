import React, {Component} from 'react';
import Swal from 'sweetalert2'
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import {MenuHeader} from "../components/MenuHeader";
import { loginUser,loginWithScatter} from "../utils/tronweb";
import { Link} from "react-router-dom";
import {account} from "../utils/tronweb";
import { Redirect } from 'react-router-dom'
import 'bootstrap';
import '../index.css';

const styles = {
    card: {
        maxWidth: 275,
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    title: {
        fontSize: 14,
    },
    pos: {
        marginBottom: 12,
    },
};

class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
            userName : localStorage.getItem("userName"),
            password: 'password',
            toDashboard: false

        };
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleUserChange = this.handleUserChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

        // const username =  tronWeb.defaultAddress.base58;
    }


    static contextTypes = {
        router: PropTypes.object,
    }

    handleUserChange (event){
        console.log(event.target);
        this.setState({
            userName: event.target.value,
        });
    };
    handlePasswordChange(event){
        console.log(event.target.value);
        this.setState({
            password: event.target.value,
        });
    };

    handleSubmit(event) {
        console.log(this.state.userName);
        loginUser( this.state.userName, this.state.password);
        event.preventDefault();
    }


    async checkUser(event) {
        await loginWithScatter().then(res =>{
            const timer = setInterval(() => {
                if(account != null){
                    clearInterval(timer);
this.props.navigate('home');
                    console.log("address",account.address);

                }

            }, 5);

        }).catch(err=>{


        });




    }

    /* async  checkUser(){
         console.log("Enter True");

         var res = await loginWithScatter();
             console.log("response", res);

             setTimeout(() =>{
                 if (res != null) {
                     Swal.fire({
                         title: 'Login Confirmed',
                         type: 'info'
                     });
                     console.log("DATA", res)
                 }
             }, 2000);



         /!*if(flag.toString()){
             console.log("Enter True",flag);

         }else{
             Swal.fire({title:'Login Failed',
                 type: 'error'
             });
         }*!/
     }*/

    render() {

        let userName = localStorage.getItem("userName");
        console.log(userName);

        return (

            <div className="card loginCard">
                <form onSubmit={this.handleSubmit}>
                    <div className="vl">
                        <span className="vl-innertext">or</span>
                    </div>
                    <div className="row">
                        <div className="col leftCard">
                            <button type="button" className="btn btn-primary btn-lg btn-block tronBtn">Sign in with TronLink</button>
                            <button type="button" className="btn btn-secondary btn-lg btn-block scatterBtn" onClick={this.checkUser}>Sign in with Scatter</button>
                            <button type="button" className="btn btn-secondary btn-lg btn-block fbBtn" >Sign in with Facebook</button></div>
                        <div className="col rightCard">
                            <h5 className="loginHeader text-info">Sign In Manually!</h5>
                            <div className="form-group">
                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                                       placeholder="Enter email"/>
                            </div>
                            <div className="form-group">
                                <input type="password" className="form-control" id="exampleInputPassword1"
                                       placeholder="Password"/>
                            </div>
                            <div>
                                <button type="button" className="btn  loginBtn">Login</button>
                                <span>
                        <a href="#">Register Here</a>
                    </span></div>
                        </div>
                    </div>

                </form>
            </div>
        );

    }
}
Login.propTypes = {
    classes: PropTypes.object.isRequired,
};
export default  withStyles(styles)(Login);
