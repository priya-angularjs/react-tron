import React, {Component} from 'react';
import PropTypes from 'prop-types';
import Card from '@material-ui/core/Card';
import { withStyles } from '@material-ui/core/styles';
import Form from 'react-bootstrap/Form';
import { loginUser} from "../utils/tronweb";
import '../index.css';
const http = require('http');
const $ = require('jquery');
const SendOtp = require('sendotp');
var otpGenerator = require('otp-generator');
const styles = {
    card: {
        maxWidth: 275,
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    title: {
        fontSize: 14,
    },
    pos: {
        marginBottom: 12,
    },
};

class LoginRegister extends Component {

    constructor(props) {
        super(props);
        this.state = {
            userName : '',
            password: '',
            confirmPassword: '',
            email: '',
            phoneNumber: ''
        };
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleUserChange = this.handleUserChange.bind(this);
        this.handleConfirmPasswordChange = this.handleConfirmPasswordChange.bind(this);
        this.handleEmailChange = this.handleEmailChange.bind(this);
        this.handlePhoneNoChange = this.handlePhoneNoChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        // const username =  tronWeb.defaultAddress.base58;
    }


    handleUserChange (event){
        console.log(event.target);
        this.setState({
            userName: event.target.value,
        });
    };
    handlePasswordChange(event){
        console.log(event.target.value);
        this.setState({
            password: event.target.value,
        });
    };
    handleConfirmPasswordChange(event){
        console.log(event.target.value);
        this.setState({
            confirmPassword: event.target.value,
        });
    }
    handleEmailChange(event){
        console.log(event.target.value);
        this.setState({
            email: event.target.value,
        });
    }
    handlePhoneNoChange(event){
        console.log(event.target.value);
        this.setState({
            phoneNumber: event.target.value,
        });
    }

    handleSubmit(event) {
        console.log(this.state.phoneNumber);
        console.log( this.state.userName);

        const phoneNo = this.state.phoneNumber;
        const otp = otpGenerator.generate(6, { alphabets: false,
            digits : true,upperCase: false, specialChars: false});

        console.log(otp);

        const settings = {
            async: true,
            crossOrigin: true,
            url: "http://control.msg91.com/api/sendotp.php?otp_length=6&authkey=274122AXea188QpEe5cc329df&message=your Verification code is "+otp+" please do not share with anyone&sender=TRONFX&" +
                "mobile="+this.state.phoneNumber +"&otp=" +otp+ "&otp_expiry=1440",
            type: "POST",
            headers: {"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": ""}
        };

        $.ajax(settings).done(function (response) {
            console.log(response);
        });

 /*       const options = {
            otp_length: 6,
            authkey: '274122AXea188QpEe5cc329df',
            message: "your Verification code is "+otp+" please do not share with anyone",
            sender: 'TRONFX',
            mobile: this.state.phoneNumber,
            otp: otp,
            otp_expiry: 1440
        };

        $.ajax({
            crossOrigin: true,
            url: "http://control.msg91.com/api/sendotp.php?otp_length=6&authkey=274122AXea188QpEe5cc329df&message=your Verification code is "+otp+" please do not share with anyone&sender=TRONFX&" +
                "mobile="+this.state.phoneNumber +"&otp=" +otp+ "&otp_expiry=1440",
            type: 'json',
            method: "post",
            mimeType: 'text/html',
            data: options,
            contentType: "application/json",
            accept: '',
            headers: {"Access-Control-Allow-Origin": "http://localhost:3000"},
            success: function (response) {
                console.log(response);
            },
            error: function (error) {
                console.log(error);
            }
        });*/

  /*      const url = "http://control.msg91.com/api/sendotp.php?otp_length=6&authkey=274122AXea188QpEe5cc329df&message=your Verification code is "+otp+" please do not share with anyone&sender=TRONFX&" +
            "mobile="+this.state.phoneNumber +"&otp= " +otp+ "&otp_expiry=1440"; // site that doesn’t send Access-Control-*
        fetch(url, {method: 'post',
            mode: 'no-cors',
            credentials: true,
            headers: {"Access-Control-Allow-Origin": "*","Access-Control-Allow-Headers": "origin"}})
            .then(response => console.log(response))
            .then(contents => console.log(contents))
            .catch(() => console.log("Can’t access " + url + " response. Blocked by browser?"))*/

        loginUser( this.state.userName, this.state.password);
        event.preventDefault();
    }
    render() {

        let userName = localStorage.getItem("userName");
        console.log(userName);
        return (
            <Card className="login">
                <Form onSubmit={this.handleSubmit}>
                    <h3 className="loginHeader text-info">Welcome to Blog Dapp !</h3>
                    <Form.Group controlId="formHorizontalEmail">
                        <Form.Label className="labelAlign">
                            <b className="text-info"> Username :</b>
                        </Form.Label>
                        <Form.Control type="text" placeholder="Enter your Username" maxLength={50}  value={this.state.userName}  onChange={this.handleUserChange}/>
                    </Form.Group>
                    <Form.Group controlId="formHorizontalEmail">
                        <Form.Label className="labelAlign">
                            <b className="text-info"> Email :</b>
                        </Form.Label>
                        <Form.Control type="text" placeholder="Enter your Email" maxLength={50}  value={this.state.email}  onChange={this.handleEmailChange}/>
                    </Form.Group>
                    <Form.Group controlId="formHorizontalEmail">
                        <Form.Label>
                            <b className="text-info"> Password : </b>
                        </Form.Label>
                        <Form.Control type="password" placeholder="Enter Your Password" maxLength={120} value={this.state.password}  onChange={this.handlePasswordChange}/>
                    </Form.Group>
                    <Form.Group controlId="formHorizontalEmail">
                        <Form.Label>
                            <b className="text-info"> Confirm Password : </b>
                        </Form.Label>
                        <Form.Control type="password" placeholder="Reconfirm Password" maxLength={120} value={this.state.confirmPassword}  onChange={this.handleConfirmPasswordChange}/>
                    </Form.Group>
                    <Form.Group controlId="formHorizontalEmail">
                        <Form.Label>
                            <b className="text-info"> Phone Number: </b>
                        </Form.Label>
                        <Form.Control type="text" placeholder="Enter Your Phone Number" maxLength={120}  value={this.state.phoneNumber}  onChange={this.handlePhoneNoChange}/>
                    </Form.Group>
                    <Form.Group>
                        <input type="submit" className="btn btn-outline-dark" value="Submit"/>
                    </Form.Group>




                </Form>




            </Card>
        );

    }
}
LoginRegister.propTypes = {
    classes: PropTypes.object.isRequired,
};
export default  withStyles(styles)(LoginRegister);
