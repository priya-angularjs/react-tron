import React, {Component} from 'react';
import './App.css';
import { HashRouter as Router, Route } from "react-router-dom";
import Login from './components/Login';
import LoginRegister from "./components/LoginRegister";

class App extends Component {
    render() {
        return (
            <Router>
            <div className="App">
                <div className="container">
                    <Route path="/" exact component={LoginP} />
                    <Route path = "/register" component ={LoginRegisterP} />
                </div>
            </div></Router>
        );
    }
}
const LoginP = () => <Login filterword={"/"}/>;
const LoginRegisterP = () => <LoginRegister /> ;

export default App;
